package com.example.zkbdemo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


import com.adobe.marketing.mobile.AdobeCallback;
import com.adobe.marketing.mobile.AdobeCallbackWithError;
import com.adobe.marketing.mobile.AdobeError;
import com.adobe.marketing.mobile.Assurance;
import com.adobe.marketing.mobile.Edge;
import com.adobe.marketing.mobile.Lifecycle;
import com.adobe.marketing.mobile.LoggingMode;
import com.adobe.marketing.mobile.MobileCore;
import com.adobe.marketing.mobile.Signal;
import com.adobe.marketing.mobile.UserProfile;
import com.adobe.marketing.mobile.edge.consent.Consent;
import com.adobe.marketing.mobile.edge.identity.Identity;
import java.util.Arrays;
import java.util.List;

import java.io.IOException;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {


    public String EcidForAPI = "";

    public static final MediaType JSON = MediaType.parse("application/json; charset=utf-8");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MobileCore.setApplication(this.getApplication());
        MobileCore.setLogLevel(LoggingMode.DEBUG);

        List extensions = Arrays.asList(
                com.adobe.marketing.mobile.edge.identity.Identity.EXTENSION,
                Lifecycle.EXTENSION,
                Signal.EXTENSION,
                UserProfile.EXTENSION,
                Edge.EXTENSION,
                Assurance.EXTENSION,
                Consent.EXTENSION
        );

        MobileCore.registerExtensions(extensions, new AdobeCallback () {
            @Override
            public void call(Object o) {
                MobileCore.configureWithAppID("2fd35f2549c1/9288e3b25d41/launch-4663bb79b918-development");
            }
        });


        setContentView(R.layout.activity_main);

        Identity.getExperienceCloudId(new AdobeCallbackWithError<String>() {
            @Override
            public void call(String ecid) {
                //Handle the ID returned here
                EcidForAPI = ecid;
                TextView adobeECID = (TextView) findViewById(R.id.txtECID);
                adobeECID.setText(EcidForAPI);
                Log.d("postEdgeNetworkAPIRequest ECID",EcidForAPI);
                /*try {
                    postEdgeNetworkAPIRequest();
                } catch (IOException e) {
                    e.printStackTrace();
                }*/
            }
            @Override
            public void fail(AdobeError adobeError) {
                Log.d("postEdgeNetworkAPIRequest ECID Error",String.valueOf(adobeError));
            }
        });


        //Assurance debug starts
            final Button btnConnectToAssuranceSession = findViewById(R.id.btnConnectToAssuranceSession);
            final EditText txtAssuranceSessionURL = findViewById(R.id.txtAssuranceSessionURL);
            // start session
            btnConnectToAssuranceSession.setOnClickListener(v -> Assurance.startSession(txtAssuranceSessionURL.getText().toString()));
        //Assurance debug ends

    }

    void postEdgeNetworkAPIRequest() throws IOException {

        String postUrl= "https://edge.adobedc.net/ee/ind1/v2/interact?dataStreamId=158b16f9-45fd-4f62-9411-ca551e057d4b";
        String postBody = "{\"event\":{\"xdm\":{\"eventType\":\"web.webpagedetails.pageViews\",\"identityMap\":{\"ECID\":[{\"id\":\""+EcidForAPI+"\",\"authenticatedState\":\"ambiguous\",\"primary\":true}]}}},\"query\":{\"personalization\":{\"schemas\":[\"https://ns.adobe.com/personalization/html-content-item\",\"https://ns.adobe.com/personalization/json-content-item\",\"https://ns.adobe.com/personalization/redirect-item\",\"https://ns.adobe.com/personalization/dom-action\"],\"decisionScopes\":[\"zkb_demo_edge_api\"]}}}";

        Log.d("postEdgeNetworkAPIRequest payload",postBody);

        OkHttpClient client = new OkHttpClient();

        RequestBody body = RequestBody.create(JSON, postBody);

        Request request = new Request.Builder()
                .url(postUrl)
                .post(body)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d("postEdgeNetworkAPIRequest Error",String.valueOf(e));
                call.cancel();
            }
            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d("postEdgeNetworkAPIRequest Response",response.body().string());
            }
        });
    }


    @Override
    public void onResume() {
        super.onResume();
        MobileCore.setApplication(getApplication());
        MobileCore.lifecycleStart(null);
    }

    @Override
    public void onPause() {
        super.onPause();
        MobileCore.lifecyclePause();
    }

}